﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel;
using WpfMVVM.Models;
using WpfMVVM.Commands;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using System.IO;

namespace WpfMVVM.ViewModels
{
    public class EmployeeViewModel : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged implementation
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
        
        EmployeeService ObjEmployeeService;
        public EmployeeViewModel()
        {
            ObjEmployeeService = new EmployeeService();
            LoadData();
            CurrentEmployee = new Employee();
            saveCommand = new RelayCommands(Save);
            clearCommand = new RelayCommands(Clear);
            searchCommand = new RelayCommands(Search);
            updateCommand = new RelayCommands(Update);
            deleteCommand = new RelayCommands(Delete);
            inputImage = new RelayCommands(ImgLoad);
        }


        private string message;

        public string Message
        {
            get { return message; }
            set { message = value; OnPropertyChanged("Message"); }
        }

        #region Data display in data grid
        private ObservableCollection<Employee> employeesList;
        public ObservableCollection<Employee> EmployeesList
        {
            get { return employeesList; }
            set { employeesList = value; OnPropertyChanged("EmployeesList"); }
        }

        private void LoadData()
        {
            try
            {
                EmployeesList = new ObservableCollection<Employee>(ObjEmployeeService.GetAllEmployees());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading employees: " + ex.Message);
            }
        }
        #endregion


        #region Save operation 
        private Employee currentEmployee;
        public Employee CurrentEmployee
        {
            get { return currentEmployee; }
            set { currentEmployee = value; OnPropertyChanged("CurrentEmployee"); }
        }

        private readonly RelayCommands saveCommand;
        public RelayCommands SaveCommand
        {
            get { return saveCommand; }
        }

        public void Save()
        {
            try
            {
                var IsSaved = ObjEmployeeService.Add(currentEmployee);
                LoadData();
                if (IsSaved)
                {
                    Message = "Employee Saved";
                    Clear();
                }
                else
                {
                    Message = "Save Failed";
                }
            }
            catch(Exception ex)
            {
                Message = ex.Message;
            }
        }
        #endregion


        #region Clear input fields
        private readonly RelayCommands clearCommand;
        public RelayCommands ClearCommand
        {
            get { return clearCommand; }
        }

        private void Clear()
        {
            CurrentEmployee = new Employee();
        }

        #endregion


        #region search data
        private readonly RelayCommands searchCommand;
        public RelayCommands SearchCommand
        {
            get { return searchCommand; }
        }

        private void Search()
        {
            try
            {
                var ObjEmployee = ObjEmployeeService.Search(CurrentEmployee.ID);
                if (ObjEmployee != null)
                {
                    currentEmployee.Name = ObjEmployee.Name;
                    currentEmployee.Age = ObjEmployee.Age;
                }
                else
                {
                    Message = "Employee Not Found";
                }
            }
            catch (Exception ex)
            {

                Message = ex.Message;
            }
        }
        #endregion


        #region Update 
        private RelayCommands updateCommand;

        public RelayCommands UpdateCommand
        {
            get { return updateCommand; }
        }

        public void Update()
        {
            try
            {
                var IsUpdated = ObjEmployeeService.Update(currentEmployee);
                if (IsUpdated)
                {
                    Message = "Employee Updated";
                    LoadData();
                    Clear();
                }
                else
                {
                    Message = "Updated Operation Failed";
                }
            }
            catch (Exception ex)
            {

                Message = ex.Message;
            }
        }
        #endregion


        #region delete 
        private RelayCommands deleteCommand;

        public RelayCommands DeleteCommand
        {
            get { return deleteCommand; }
        }

        public void Delete()
        {
            try
            {
                var IsDelete = ObjEmployeeService.Delete(CurrentEmployee.ID);
                if (IsDelete)
                {
                    Message = "Employee Deleted";
                    LoadData();
                    Clear();
                }
                else
                {
                    Message = "Delete Operation Failed";
                }
            }
            catch (Exception ex)
            {

                Message = ex.Message;
            }
        }
        #endregion



        #region browse image
        public RelayCommands inputImage;
        public RelayCommands InputImage
        {
            get { return inputImage; }
            set
            {
                inputImage = value;
                OnPropertyChanged(nameof(InputImage));
            }
        }

        public void ImgLoad()
        {
            try
            {
                OpenFileDialog op = new OpenFileDialog();
                op.Title = "Select a picture";
                op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
                   "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
                   "Portable Network Graphic (*.png)|*.png";
                DialogResult result = op.ShowDialog();
                if (result == DialogResult.OK)
                {
                    string filePath = op.FileName;
                    string destinationFolder = @"D:\img";
                    string fileName = Path.GetFileName(filePath);
                    string destinationPath = Path.Combine(destinationFolder, fileName);
                    if (!Directory.Exists(destinationFolder))
                    {
                        Directory.CreateDirectory(destinationFolder);
                    }
                    File.Copy(filePath, destinationPath, true);
                    //001.png
                    CurrentEmployee.Img = fileName;
                }
            }
            catch (Exception ex)
            {

                Message = ex.Message;
            }
        }


        #endregion
    }
}
