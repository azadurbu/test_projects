﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DrawOnImage
{
    /// <summary>
    /// Interaction logic for DrawOnImage.xaml
    /// </summary>


    //drawing wiht InkCanvas
    //public partial class DrawingImage : UserControl
    //{
    //    int isInitialize = 0;
    //    public DrawingImage()
    //    {
    //        InitializeComponent();
    //        inkCanvas1.DefaultDrawingAttributes.Width = brushSizeSlider.Value;
    //        inkCanvas1.DefaultDrawingAttributes.Height = brushSizeSlider.Value;
    //        inkCanvas1.DefaultDrawingAttributes.Color = Colors.Black;
    //    }

    //    // Load Image Button Click
    //    private void btnLoadImage_Click(object sender, RoutedEventArgs e)
    //    {
    //        // Open a file dialog to select an image
    //        OpenFileDialog openFileDialog = new OpenFileDialog();
    //        openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif";

    //        if (openFileDialog.ShowDialog() == true)
    //        {
    //            string filePath = openFileDialog.FileName;
    //            Uri imageUri = new Uri(filePath);
    //            BitmapImage bitmapImage = new BitmapImage(imageUri);
    //            ImageBrush imageBrush = new ImageBrush(bitmapImage);
    //            imageBrush.Stretch = Stretch.None;
    //            inkCanvas1.Background = imageBrush;


    //            inkCanvas1.Width = bitmapImage.PixelWidth;
    //            inkCanvas1.Height = bitmapImage.PixelHeight;
    //            border1.Width = bitmapImage.PixelWidth;
    //            border1.Height = bitmapImage.PixelHeight;
    //            // Adjust the Window size to match the loaded image size, with optional padding
    //            //this.Width = bitmapImage.PixelWidth;
    //            //this.Height = bitmapImage.PixelHeight;
    //            Window parentWindow = Window.GetWindow(this);
    //            parentWindow.Width = bitmapImage.PixelWidth + 35;
    //            parentWindow.Height = bitmapImage.PixelHeight;
    //        }
    //    }

    //    // Undo Button Click
    //    private void btnUndo_Click(object sender, RoutedEventArgs e)
    //    {
    //        // Erase last drawing stroke
    //        if (inkCanvas1.Strokes.Count > 0)
    //        {
    //            inkCanvas1.Strokes.Remove(inkCanvas1.Strokes[inkCanvas1.Strokes.Count - 1]);
    //        }
    //    }

    //    // Save Button Click
    //    private void btnSave_Click(object sender, RoutedEventArgs e)
    //    {
    //        // Open a save file dialog to select where to save the image
    //        SaveFileDialog saveFileDialog = new SaveFileDialog();
    //        saveFileDialog.Filter = "JPEG Image(*.jpg)|*.jpg|BMP Image (*.bmp*)|*.bmp|PNG Image(*.png)|*.png|GIF Image(*.gif)|*.gif";

    //        if (saveFileDialog.ShowDialog() == true)
    //        {
    //            string filePath = saveFileDialog.FileName;
    //            // Create a render target to save the ink canvas as an image
    //            RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int)inkCanvas1.ActualWidth, (int)inkCanvas1.ActualHeight, 96, 96, PixelFormats.Pbgra32);
    //            renderTargetBitmap.Render(inkCanvas1);

    //            // Save the image
    //            PngBitmapEncoder encoder = new PngBitmapEncoder();
    //            encoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));

    //            using (FileStream fs = new FileStream(filePath, FileMode.Create))
    //            {
    //                encoder.Save(fs);
    //            }
    //        }
    //    }
    //    private void btnEraserBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        inkCanvas1.EditingMode = InkCanvasEditingMode.EraseByPoint;
    //        inkCanvas1.DefaultDrawingAttributes.Width = brushSizeSlider.Value;
    //        inkCanvas1.DefaultDrawingAttributes.Height = brushSizeSlider.Value;
    //    }

    //    private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        inkCanvas1.EditingMode = InkCanvasEditingMode.Ink;
    //        inkCanvas1.DefaultDrawingAttributes.Color = Colors.Black;
    //    }

    //    private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        inkCanvas1.EditingMode = InkCanvasEditingMode.Ink;
    //        inkCanvas1.DefaultDrawingAttributes.Color = Colors.White;
    //    }

    //    private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    //    {
    //        var slider = sender as Slider;
    //        if (isInitialize < 2)
    //        {
    //            isInitialize++;
    //            return;
    //        }
    //        if (slider.Value != e.OldValue)
    //        {
    //            inkCanvas1.DefaultDrawingAttributes.Width = slider.Value;
    //            inkCanvas1.DefaultDrawingAttributes.Height = slider.Value;
    //        }
    //    }    
    //}


    //public partial class DrawingImage : UserControl
    //{
    //    private WriteableBitmap writeableBitmap;
    //    private WriteableBitmap drawnBitmap;       // The bitmap that stores only drawn pixels
    //    private bool isDrawing = true;
    //    private bool isErasing = false;
    //    private bool isClicked = false;
    //    private int width = 500;
    //    private int height = 500;
    //    private Point previousPoint;
    //    private int brushSize = 20;
    //    private Color brushColor = Colors.Black;
    //    private Stack<WriteableBitmap> undoStack = new Stack<WriteableBitmap>();

    //    public DrawingImage()
    //    {
    //        // Initialize WriteableBitmap for background and drawing
    //        writeableBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
    //        drawnBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
    //        InitializeComponent();

    //        canvas.Width = width;
    //        canvas.Height = height;

    //        canvas.MouseMove += Canvas_MouseMove;
    //        canvas.MouseDown += Canvas_MouseDown;
    //        canvas.MouseUp += Canvas_MouseUp;
    //    }

    //    #region Mouse action
    //    private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
    //    {
    //        if (isErasing)
    //        {
    //            isDrawing = false; isClicked = true;
    //            ErasePixel((int)e.GetPosition(canvas).X, (int)e.GetPosition(canvas).Y);
    //        }
    //        if (isDrawing)
    //        {
    //            isErasing = false; isClicked = true;
    //            previousPoint = e.GetPosition(canvas);
    //            SaveUndoState();
    //        }
    //    }

    //    private void Canvas_MouseMove(object sender, MouseEventArgs e)
    //    {
    //        if (isErasing && isClicked)
    //        {
    //            ErasePixel((int)e.GetPosition(canvas).X, (int)e.GetPosition(canvas).Y);
    //        }
    //        if (isDrawing && isClicked)
    //        {
    //            var currentPoint = e.GetPosition(canvas);
    //            DrawLineOnBitmap(previousPoint, currentPoint);
    //            previousPoint = currentPoint;
    //        }
    //    }

    //    private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
    //    {
    //        isClicked = false;
    //    }
    //    #endregion

    //    #region form action
    //    private void btnLoadImage_Click(object sender, RoutedEventArgs e)
    //    {
    //        OpenFileDialog openFileDialog = new OpenFileDialog();
    //        openFileDialog.Filter = "Image Files (*.png;*.jpg;*.bmp)|*.png;*.jpg;*.bmp";
    //        if (openFileDialog.ShowDialog() == true)
    //        {
    //            var image = new System.Windows.Controls.Image();
    //            var bitmap = new System.Windows.Media.Imaging.BitmapImage(new Uri(openFileDialog.FileName));
    //            image.Source = bitmap;
    //            canvasImage.Children.Clear();
    //            canvasImage.Children.Add(image);
    //            canvas.Height = canvasImage.Height;
    //            canvas.Width = canvasImage.Width;
    //        }
    //    }

    //    private void btnSave_Click(object sender, RoutedEventArgs e)
    //    {
    //        SaveFileDialog saveFileDialog = new SaveFileDialog();
    //        saveFileDialog.Filter = "JPEG Image(*.jpg)|*.jpg|BMP Image (*.bmp*)|*.bmp|PNG Image(*.png)|*.png|GIF Image(*.gif)|*.gif";
    //        if (saveFileDialog.ShowDialog() == true)
    //        {
    //            using (var stream = saveFileDialog.OpenFile())
    //            {
    //                PngBitmapEncoder encoder = new PngBitmapEncoder();
    //                encoder.Frames.Add(BitmapFrame.Create(writeableBitmap));
    //                encoder.Save(stream);
    //            }
    //        }
    //    }

    //    private void btnUndo_Click(object sender, RoutedEventArgs e)
    //    {
    //        if (undoStack.Count > 0)
    //        {
    //            writeableBitmap = undoStack.Pop();
    //            canvas.Background = new ImageBrush(writeableBitmap);
    //        }
    //    }

    //    private void btnEraserBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        isErasing = true;
    //        isDrawing = false;
    //        brushColor = Colors.Transparent;
    //    }

    //    private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        isErasing = false;
    //        isDrawing = true;
    //        brushColor = Colors.Black;
    //    }

    //    private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        isErasing = false;
    //        isDrawing = true;
    //        brushColor = Colors.White;
    //    }

    //    private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    //    {
    //        brushSize = (int)e.NewValue;
    //    }
    //    #endregion

    //    #region Helper function
    //    private void DrawLineOnBitmap(Point start, Point end)
    //    {
    //        int x1 = (int)start.X;
    //        int y1 = (int)start.Y;
    //        int x2 = (int)end.X;
    //        int y2 = (int)end.Y;

    //        // Simple line drawing algorithm (Bresenham's Line Algorithm)
    //        int dx = Math.Abs(x2 - x1);
    //        int dy = Math.Abs(y2 - y1);
    //        int sx = (x1 < x2) ? 1 : -1;
    //        int sy = (y1 < y2) ? 1 : -1;
    //        int err = dx - dy;

    //        while (true)
    //        {
    //            // Draw a thicker line by drawing surrounding pixels
    //            for (int i = -brushSize / 2; i <= brushSize / 2; i++)
    //            {
    //                for (int j = -brushSize / 2; j <= brushSize / 2; j++)
    //                {
    //                    int dxAdjusted = x1 + i;
    //                    int dyAdjusted = y1 + j;

    //                    // Only draw if within bounds
    //                    if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
    //                        dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
    //                    {
    //                        SetPixel(dxAdjusted, dyAdjusted, brushColor);
    //                        SetPixelInDrawnBitmap(dxAdjusted, dyAdjusted, brushColor); // Store drawn pixels in drawnBitmap
    //                    }
    //                }
    //            }

    //            if (x1 == x2 && y1 == y2) break;
    //            int e2 = err * 2;
    //            if (e2 > -dy)
    //            {
    //                err -= dy;
    //                x1 += sx;
    //            }
    //            if (e2 < dx)
    //            {
    //                err += dx;
    //                y1 += sy;
    //            }
    //        }
    //    }

    //    private void SetPixelInDrawnBitmap(int x, int y, Color color)
    //    {
    //        if (x < 0 || x >= drawnBitmap.PixelWidth || y < 0 || y >= drawnBitmap.PixelHeight)
    //            return;

    //        int stride = drawnBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
    //        int index = (y * stride) + (x * 4);

    //        byte[] pixels = new byte[4];
    //        pixels[0] = color.B;
    //        pixels[1] = color.G;
    //        pixels[2] = color.R;
    //        pixels[3] = color.A;

    //        drawnBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
    //    }

    //    private void SetPixel(int x, int y, Color color)
    //    {
    //        if (x < 0 || x >= writeableBitmap.PixelWidth
    //            || y < 0 || y >= writeableBitmap.PixelHeight)
    //            return;

    //        int stride = writeableBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
    //        int index = (y * stride) + (x * 4);

    //        byte[] pixels = new byte[4];
    //        pixels[0] = color.B;
    //        pixels[1] = color.G;
    //        pixels[2] = color.R;
    //        pixels[3] = color.A;

    //        writeableBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
    //    }

    //    private void SaveUndoState()
    //    {
    //        var copyBitmap = new WriteableBitmap(writeableBitmap);
    //        undoStack.Push(copyBitmap);
    //    }

    //    private void ErasePixel(int x, int y)
    //    {
    //        // Check if the pixel is part of the drawn content
    //        if (IsDrawnPixel(x, y))
    //        {
    //            // Erase multiple pixels around the cursor based on brush size
    //            for (int i = -brushSize / 2; i <= brushSize / 2; i++)
    //            {
    //                for (int j = -brushSize / 2; j <= brushSize / 2; j++)
    //                {
    //                    int dxAdjusted = x + i;
    //                    int dyAdjusted = y + j;

    //                    // Only erase if within bounds
    //                    if (dxAdjusted >= 0 && dxAdjusted < drawnBitmap.PixelWidth &&
    //                        dyAdjusted >= 0 && dyAdjusted < drawnBitmap.PixelHeight)
    //                    {
    //                        SetPixel(dxAdjusted, dyAdjusted, Colors.Transparent); // Set to transparent to "erase"
    //                        SetPixelInDrawnBitmap(dxAdjusted, dyAdjusted, Colors.Transparent); // Erase from drawnBitmap
    //                    }
    //                }
    //            }
    //        }
    //    }

    //    private bool IsDrawnPixel(int x, int y)
    //    {
    //        byte[] pixel = new byte[4];
    //        int stride = drawnBitmap.PixelWidth * 4;
    //        drawnBitmap.CopyPixels(new Int32Rect(x, y, 1, 1), pixel, stride, 0);

    //        return pixel[0] != 0 || pixel[1] != 0 || pixel[2] != 0 || pixel[3] != 0; // Not transparent
    //    }
    //    #endregion
    //}

    public partial class DrawingImage : UserControl
    {
        private WriteableBitmap writeableBitmap;   // The background bitmap (can be an image or plain white)
        private WriteableBitmap drawnBitmap;       // The bitmap that stores only drawn pixels
        private int width = 500;
        private int height = 500;
        private bool isDrawing = true;
        private bool isErasing = false;            // To track eraser mode
        private bool isClicked = false;
        private Point previousPoint;
        private int brushSize = 20;                // Default brush size
        private Color brushColor = Colors.Black;   // Default brush color
        private Stack<WriteableBitmap> undoStack = new Stack<WriteableBitmap>(); // Undo stack


        public DrawingImage()
        {
            InitializeComponent();

            // Initialize WriteableBitmap for background and drawing
            writeableBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            drawnBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);

            ImageBrush brush = new ImageBrush(writeableBitmap);
            canvas.Background = brush;

            // Set the Canvas size to match the WriteableBitmap size
            canvas.Width = width;
            canvas.Height = height;

            // Add mouse event for drawing or erasing
            canvas.MouseMove += Canvas_MouseMove;
            canvas.MouseDown += Canvas_MouseDown;
            canvas.MouseUp += Canvas_MouseUp;
        }

        // Mouse down event to start drawing or erasing
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (isErasing)
            {
                isDrawing = false; isClicked = true;
                ErasePixel((int)e.GetPosition(canvas).X, (int)e.GetPosition(canvas).Y);
            }
            if (isDrawing)
            {
                isErasing = false; isClicked = true;
                previousPoint = e.GetPosition(canvas);
                SaveUndoState();
            }
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isErasing && isClicked)
            {
                ErasePixel((int)e.GetPosition(canvas).X, (int)e.GetPosition(canvas).Y);
            }
            if (isDrawing && isClicked)
            {
                var currentPoint = e.GetPosition(canvas);
                DrawLineOnBitmap(previousPoint, currentPoint);
                previousPoint = currentPoint;
            }
        }

        // Mouse up event to stop drawing
        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isClicked = false;
        }

        // Save the current canvas state to the undo stack
        private void SaveUndoState()
        {
            var copyBitmap = new WriteableBitmap(writeableBitmap);
            undoStack.Push(copyBitmap);
        }

        // Undo the last drawing action
        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {
            if (undoStack.Count > 0)
            {
                writeableBitmap = undoStack.Pop();
                canvas.Background = new ImageBrush(writeableBitmap); // Update canvas with undone state
            }
        }

        // Load image from file (btnLoadImage)
        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.bmp)|*.png;*.jpg;*.bmp";
            if (openFileDialog.ShowDialog() == true)
            {
                var image = new System.Windows.Controls.Image();
                var bitmap = new System.Windows.Media.Imaging.BitmapImage(new Uri(openFileDialog.FileName));
                image.Source = bitmap;
                canvasImage.Children.Clear();  // Clear any existing drawings
                canvasImage.Children.Add(image);
                canvas.Height = canvasImage.Height;
                canvas.Width = canvasImage.Width;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PNG Image (*.png)|*.png";
            if (saveFileDialog.ShowDialog() == true)
            {
                using (var stream = saveFileDialog.OpenFile())
                {
                    PngBitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(writeableBitmap));
                    encoder.Save(stream);
                }
            }
        }

        // Set Eraser Brush
        private void btnEraserBrush_Click(object sender, RoutedEventArgs e)
        {
            isErasing = true;
            brushColor = Colors.Transparent; // Set color to transparent for erasing
        }

        // Set Black Brush
        private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
        {
            isErasing = false; isDrawing = true;
            brushColor = Colors.Black; // Set color to black for drawing
        }

        // Set White Brush
        private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
        {
            isErasing = false; isDrawing = true;
            brushColor = Colors.White; // Set color to white for drawing
        }

        // Change brush size using slider
        private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            brushSize = (int)e.NewValue;
        }

        // Method to draw a line on the WriteableBitmap
        private void DrawLineOnBitmap(Point start, Point end)
        {
            int x1 = (int)start.X;
            int y1 = (int)start.Y;
            int x2 = (int)end.X;
            int y2 = (int)end.Y;

            // Simple line drawing algorithm (Bresenham's Line Algorithm)
            int dx = Math.Abs(x2 - x1);
            int dy = Math.Abs(y2 - y1);
            int sx = (x1 < x2) ? 1 : -1;
            int sy = (y1 < y2) ? 1 : -1;
            int err = dx - dy;

            while (true)
            {
                // Draw a thicker line by drawing surrounding pixels
                for (int i = -brushSize / 2; i <= brushSize / 2; i++)
                {
                    for (int j = -brushSize / 2; j <= brushSize / 2; j++)
                    {
                        int dxAdjusted = x1 + i;
                        int dyAdjusted = y1 + j;

                        // Only draw if within bounds
                        if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
                            dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
                        {
                            SetPixel(dxAdjusted, dyAdjusted, brushColor);
                            SetPixelInDrawnBitmap(dxAdjusted, dyAdjusted, brushColor); // Store drawn pixels in drawnBitmap
                        }
                    }
                }

                if (x1 == x2 && y1 == y2) break;
                int e2 = err * 2;
                if (e2 > -dy)
                {
                    err -= dy;
                    x1 += sx;
                }
                if (e2 < dx)
                {
                    err += dx;
                    y1 += sy;
                }
            }
        }

        // Set a pixel to a specific color in the main bitmap
        private void SetPixel(int x, int y, Color color)
        {
            if (x < 0 || x >= writeableBitmap.PixelWidth || y < 0 || y >= writeableBitmap.PixelHeight)
                return;

            int stride = writeableBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
            int index = (y * stride) + (x * 4);

            byte[] pixels = new byte[4];
            pixels[0] = color.B;
            pixels[1] = color.G;
            pixels[2] = color.R;
            pixels[3] = color.A;

            writeableBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
        }

        // Set a pixel in the drawnBitmap to indicate it has been drawn
        private void SetPixelInDrawnBitmap(int x, int y, Color color)
        {
            if (x < 0 || x >= drawnBitmap.PixelWidth || y < 0 || y >= drawnBitmap.PixelHeight)
                return;

            int stride = drawnBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
            int index = (y * stride) + (x * 4);

            byte[] pixels = new byte[4];
            pixels[0] = color.B;
            pixels[1] = color.G;
            pixels[2] = color.R;
            pixels[3] = color.A;

            drawnBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
        }

        // Method to erase a pixel (only erase drawn pixels, not background)
        private void ErasePixel(int x, int y)
        {
            // Check if the pixel is part of the drawn content
            if (IsDrawnPixel(x, y))
            {
                // Erase multiple pixels around the cursor based on brush size
                for (int i = -brushSize / 2; i <= brushSize / 2; i++)
                {
                    for (int j = -brushSize / 2; j <= brushSize / 2; j++)
                    {
                        int dxAdjusted = x + i;
                        int dyAdjusted = y + j;

                        // Only erase if within bounds
                        if (dxAdjusted >= 0 && dxAdjusted < drawnBitmap.PixelWidth &&
                            dyAdjusted >= 0 && dyAdjusted < drawnBitmap.PixelHeight)
                        {
                            SetPixel(dxAdjusted, dyAdjusted, Colors.Transparent); // Set to transparent to "erase"
                            SetPixelInDrawnBitmap(dxAdjusted, dyAdjusted, Colors.Transparent); // Erase from drawnBitmap
                        }
                    }
                }
            }
        }

        // Check if the pixel is drawn (not part of the background)
        private bool IsDrawnPixel(int x, int y)
        {
            byte[] pixel = new byte[4];
            int stride = drawnBitmap.PixelWidth * 4;
            try
            {
                drawnBitmap.CopyPixels(new Int32Rect(x, y, 1, 1), pixel, stride, 0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            

            return pixel[0] != 0 || pixel[1] != 0 || pixel[2] != 0 || pixel[3] != 0; // Not transparent
        }
    }
}
