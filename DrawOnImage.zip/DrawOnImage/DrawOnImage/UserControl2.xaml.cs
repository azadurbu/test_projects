﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DrawOnImage
{
    /// <summary>
    /// Interaction logic for UserControl2.xaml
    /// </summary>
    
    public partial class UserControl2 : UserControl
    {
        private WriteableBitmap writeableBitmap;
        private int width = 1000;
        private int height = 1000;
        int isInitialize = 0;
        private bool isErasing = false;
        private bool isClicked = false;
        private int brushSize = 20;
        ImageBrush brush = null;

        public UserControl2()
        {
            InitializeComponent();
            inkCanvas1.DefaultDrawingAttributes.Width = brushSizeSlider.Value;
            inkCanvas1.DefaultDrawingAttributes.Height = brushSizeSlider.Value;
            inkCanvas1.DefaultDrawingAttributes.Color = Colors.Black;

            writeableBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            brush = new ImageBrush(writeableBitmap);
            inkCanvas1.Background = brush;

            // Set the Canvas size to match the WriteableBitmap size
            inkCanvas1.Width = width;
            inkCanvas1.Height = height;
            canvas.Height = height;
            canvas.Width = width;
            canvas1.Height = height;
            canvas1.Width = width;

            canvas.MouseDown += Canvas_MouseDown;
            canvas.MouseMove += Canvas_MouseMove;
            canvas.MouseUp += Canvas_MouseUp;
        }

        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (isErasing)
            {
                isClicked = true;
                ErasePixel((int)e.GetPosition(canvas).X, (int)e.GetPosition(canvas).Y);
            }
        }

        private void ErasePixel(int x, int y)
        {
            // Erase multiple pixels around the cursor based on brush size
            for (int i = -brushSize / 2; i <= brushSize / 2; i++)
            {
                for (int j = -brushSize / 2; j <= brushSize / 2; j++)
                {
                    int dxAdjusted = x + i;
                    int dyAdjusted = y + j;

                    // Only erase if within bounds
                    if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
                        dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
                    {
                        SetPixel(dxAdjusted, dyAdjusted, Colors.Transparent); // Set to transparent to "erase"
                    }
                }
            }
        }

        private void SetPixel(int x, int y, Color color)
        {
            if (x < 0 || x >= writeableBitmap.PixelWidth || y < 0 || y >= writeableBitmap.PixelHeight)
                return;

            int stride = writeableBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
            int index = (y * stride) + (x * 4);

            byte[] pixels = new byte[4];
            pixels[0] = color.B;
            pixels[1] = color.G;
            pixels[2] = color.R;
            pixels[3] = color.A;

            writeableBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isErasing && isClicked)
            {
                // Erase when mouse is moved and in erase mode
                ErasePixel((int)e.GetPosition(canvas).X, (int)e.GetPosition(canvas).Y);
            }
        }

        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isClicked = false;
            if (!isErasing)
            {
                RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int)inkCanvas1.ActualWidth, (int)inkCanvas1.ActualHeight, 96, 96, PixelFormats.Pbgra32);
                renderTargetBitmap.Render(inkCanvas1);
                ImageBrush imageBrush = new ImageBrush(renderTargetBitmap);
                canvas.Background = imageBrush;

                inkCanvas1.Background = brush;
                inkCanvas1.Visibility = Visibility.Collapsed;
            }
        }

        // Load Image Button Click
        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            // Open a file dialog to select an image
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif";

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                Uri imageUri = new Uri(filePath);
                BitmapImage bitmapImage = new BitmapImage(imageUri);
                ImageBrush imageBrush = new ImageBrush(bitmapImage);
                imageBrush.Stretch = Stretch.None;
                canvas1.Background = imageBrush;
                canvas1.Height = bitmapImage.PixelHeight;
                canvas1.Width = bitmapImage.PixelWidth;

                canvas.Height = bitmapImage.PixelHeight;
                canvas.Width = bitmapImage.PixelWidth;

                inkCanvas1.Width = bitmapImage.PixelWidth;
                inkCanvas1.Height = bitmapImage.PixelHeight;

                border1.Width = bitmapImage.PixelWidth;
                border1.Height = bitmapImage.PixelHeight;
                
                Window parentWindow = Window.GetWindow(this);
                parentWindow.Width = bitmapImage.PixelWidth + 35;
                parentWindow.Height = bitmapImage.PixelHeight;
            }
        }

        // Undo Button Click
        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {
            // Erase last drawing stroke
            if (inkCanvas1.Strokes.Count > 0)
            {
                inkCanvas1.Strokes.Remove(inkCanvas1.Strokes[inkCanvas1.Strokes.Count - 1]);
            }
        }

        // Save Button Click
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // Open a save file dialog to select where to save the image
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JPEG Image(*.jpg)|*.jpg|BMP Image (*.bmp*)|*.bmp|PNG Image(*.png)|*.png|GIF Image(*.gif)|*.gif";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                // Create a render target to save the ink canvas as an image
                RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int)canvas.ActualWidth, (int)canvas.ActualHeight, 96, 96, PixelFormats.Pbgra32);
                renderTargetBitmap.Render(canvas);

                // Save the image
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));

                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    encoder.Save(fs);
                }
            }
        }
        private void btnEraserBrush_Click(object sender, RoutedEventArgs e)
        {
            isErasing = true;
            border1.Visibility = Visibility.Collapsed;
            //inkCanvas1.EditingMode = InkCanvasEditingMode.EraseByPoint;
            //inkCanvas1.DefaultDrawingAttributes.Width = brushSizeSlider.Value;
            //inkCanvas1.DefaultDrawingAttributes.Height = brushSizeSlider.Value;
        }

        private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
        {
            isErasing = false;
            border1.Visibility = Visibility.Visible;
            inkCanvas1.EditingMode = InkCanvasEditingMode.Ink;
            inkCanvas1.DefaultDrawingAttributes.Color = Colors.Black;
        }

        private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
        {
            isErasing = false;
            border1.Visibility = Visibility.Visible;
            inkCanvas1.EditingMode = InkCanvasEditingMode.Ink;
            inkCanvas1.DefaultDrawingAttributes.Color = Colors.White;
        }

        private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            var slider = sender as Slider;
            if (isInitialize < 2)
            {
                isInitialize++;
                return;
            }
            if (slider.Value != e.OldValue)
            {
                inkCanvas1.DefaultDrawingAttributes.Width = slider.Value;
                inkCanvas1.DefaultDrawingAttributes.Height = slider.Value;
            }
        }
    }
}
