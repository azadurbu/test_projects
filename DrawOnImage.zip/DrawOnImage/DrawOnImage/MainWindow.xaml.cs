using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DrawOnImage
{
    //public partial class MainWindow : Window
    //{
    //    private bool _isDrawing;
    //    private bool _isEraserActive;
    //    private Point _lastPoint;
    //    private Brush _brushColor = Brushes.Black;  // Default brush color
    //    private int _brushSize = 20;
    //    private Image _loadedImage;  // Store the loaded image
    //    private List<UIElement> _drawnElements = new List<UIElement>();  // List of drawn elements for eraser and undo
    //    private Rect _imageBounds;  // To store the image bounds for restricted drawing

    //    public MainWindow()
    //    {
    //        InitializeComponent();
    //    }

    //    // Button to load an image onto the canvas
    //    private void btnLoadImage_Click(object sender, RoutedEventArgs e)
    //    {
    //        OpenFileDialog openFileDialog = new OpenFileDialog();
    //        openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
    //        if (openFileDialog.ShowDialog() == true)
    //        {
    //            // Load image from file
    //            BitmapImage imageSource = new BitmapImage(new Uri(openFileDialog.FileName));

    //            // Create Image element and set its source
    //            _loadedImage = new Image
    //            {
    //                Source = imageSource,
    //                Stretch = System.Windows.Media.Stretch.UniformToFill  // Maintain aspect ratio
    //            };

    //            // Set image size to fit within the canvas dimensions while preserving aspect ratio
    //            double width = imgCanvas.ActualWidth;
    //            double height = imgCanvas.ActualHeight;

    //            // Maintain the aspect ratio of the image when resizing
    //            double aspectRatio = imageSource.Width / imageSource.Height;
    //            if (width / height > aspectRatio)
    //            {
    //                _loadedImage.Width = height * aspectRatio;
    //                _loadedImage.Height = height;
    //            }
    //            else
    //            {
    //                _loadedImage.Width = width;
    //                _loadedImage.Height = width / aspectRatio;
    //            }

    //            // Add the image to the canvas and center it
    //            imgCanvas.Children.Clear();  // Clear previous content if any
    //            Canvas.SetLeft(_loadedImage, (imgCanvas.ActualWidth - _loadedImage.Width) / 2);
    //            Canvas.SetTop(_loadedImage, (imgCanvas.ActualHeight - _loadedImage.Height) / 2);

    //            imgCanvas.Children.Add(_loadedImage);

    //            // Store the bounds of the image for drawing restrictions
    //            _imageBounds = new Rect(Canvas.GetLeft(_loadedImage), Canvas.GetTop(_loadedImage), _loadedImage.Width, _loadedImage.Height);
    //        }
    //    }


    //    // Save the current drawing to an image file
    //    private void btnSave_Click(object sender, RoutedEventArgs e)
    //    {
    //        SaveFileDialog saveFileDialog = new SaveFileDialog();
    //        saveFileDialog.Filter = "PNG Image|*.png";
    //        if (saveFileDialog.ShowDialog() == true)
    //        {
    //            RenderTargetBitmap renderBitmap = new RenderTargetBitmap((int)imgCanvas.ActualWidth, (int)imgCanvas.ActualHeight, 96, 96, PixelFormats.Pbgra32);
    //            renderBitmap.Render(imgCanvas);

    //            PngBitmapEncoder pngEncoder = new PngBitmapEncoder();
    //            pngEncoder.Frames.Add(BitmapFrame.Create(renderBitmap));

    //            using (FileStream fs = new FileStream(saveFileDialog.FileName, FileMode.Create))
    //            {
    //                pngEncoder.Save(fs);
    //            }
    //        }
    //    }

    //    // Button to set the brush color to Black
    //    private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        _brushColor = Brushes.Black;
    //        _isEraserActive = false;
    //    }

    //    // Button to set the brush color to White (for eraser)
    //    private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
    //    {
    //        _brushColor = Brushes.White;
    //        _isEraserActive = false;
    //    }

    //    private void btnEraser_Click(object sender, RoutedEventArgs e)
    //    {
    //        _isEraserActive = true;  // Activate the eraser tool
    //        _brushColor = Brushes.White;  // Eraser will use white brush color
    //    }

    //    // Brush size change handler
    //    private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    //    {
    //        _brushSize = (int)e.NewValue;
    //    }

    //    // MouseDown event to start drawing
    //    private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
    //    {
    //        if (_imageBounds.Contains(e.GetPosition(imgCanvas)))
    //        {
    //            _isDrawing = true;
    //            _lastPoint = e.GetPosition(imgCanvas); // Get current mouse position
    //            imgCanvas.CaptureMouse();
    //        }
    //    }

    //    // MouseMove event for drawing or erasing on the canvas
    //    private void Canvas_MouseMove(object sender, MouseEventArgs e)
    //    {
    //        if (_isDrawing && _imageBounds.Contains(e.GetPosition(imgCanvas)))
    //        {
    //            Point currentPoint = e.GetPosition(imgCanvas);

    //            if (_isEraserActive)
    //            {
    //                // Eraser Mode: Remove objects under the pointer
    //                Erase(currentPoint);
    //            }
    //            else
    //            {
    //                // Drawing Mode: Draw new shapes if eraser is not active
    //                Draw(_lastPoint, currentPoint);
    //            }

    //            _lastPoint = currentPoint;
    //        }
    //    }

    //    // MouseUp event to stop drawing
    //    private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
    //    {
    //        _isDrawing = false;
    //        imgCanvas.ReleaseMouseCapture();
    //    }

    //    // Eraser logic: Erases objects (lines or circles) within the eraser size (radius)
    //    private void Erase(Point currentPoint)
    //    {
    //        List<UIElement> elementsToRemove = new List<UIElement>();

    //        // Check all elements (lines, ellipses) for intersection with the eraser area
    //        foreach (var child in imgCanvas.Children)
    //        {
    //            if (child is Line line && IsLineWithinEraseArea(line, currentPoint))
    //            {
    //                elementsToRemove.Add(line);
    //            }
    //            else if (child is Ellipse ellipse && IsEllipseWithinEraseArea(ellipse, currentPoint))
    //            {
    //                elementsToRemove.Add(ellipse);
    //            }
    //        }

    //        // Remove the elements that are within the eraser area
    //        foreach (var element in elementsToRemove)
    //        {
    //            imgCanvas.Children.Remove(element);
    //        }
    //    }

    //    // Check if a line is within the eraser area
    //    private bool IsLineWithinEraseArea(Line line, Point currentPoint)
    //    {
    //        double eraserRadius = _brushSize / 2;
    //        return (Math.Abs(line.X1 - currentPoint.X) < eraserRadius || Math.Abs(line.X2 - currentPoint.X) < eraserRadius) &&
    //               (Math.Abs(line.Y1 - currentPoint.Y) < eraserRadius || Math.Abs(line.Y2 - currentPoint.Y) < eraserRadius);
    //    }

    //    // Check if an ellipse is within the eraser area
    //    private bool IsEllipseWithinEraseArea(Ellipse ellipse, Point currentPoint)
    //    {
    //        double centerX = Canvas.GetLeft(ellipse) + ellipse.Width / 2;
    //        double centerY = Canvas.GetTop(ellipse) + ellipse.Height / 2;
    //        double distance = Math.Sqrt(Math.Pow(currentPoint.X - centerX, 2) + Math.Pow(currentPoint.Y - centerY, 2));
    //        return distance <= _brushSize / 2;
    //    }

    //    // Draw a line between two points
    //    private void Draw(Point start, Point end)
    //    {
    //        DrawLine(start, end);
    //        var j = 999;
    //        var count = (end - start) / j;

    //        if (count.X > 0 || count.Y > 0)
    //        {
    //            for (int i = 0; i < j; i++)
    //                DrawCircle(start + count);
    //        }
    //        else
    //        {
    //            DrawCircle(end);
    //        }
    //    }

    //    private void DrawCircle(Point center)
    //    {
    //        Ellipse circle = new Ellipse
    //        {
    //            Fill = _brushColor,
    //            Width = _brushSize,
    //            Height = _brushSize
    //        };

    //        Canvas.SetLeft(circle, center.X - _brushSize / 2);
    //        Canvas.SetTop(circle, center.Y - _brushSize / 2);

    //        imgCanvas.Children.Add(circle);
    //    }

    //    private void DrawLine(Point startPoint, Point endPoint)
    //    {
    //        Line line = new Line
    //        {
    //            Stroke = _brushColor,
    //            StrokeThickness = _brushSize,
    //            X1 = startPoint.X,
    //            Y1 = startPoint.Y,
    //            X2 = endPoint.X,
    //            Y2 = endPoint.Y
    //        };

    //        imgCanvas.Children.Add(line);
    //    }
    //}


    public partial class MainWindow : Window
    {
        private bool isDrawing;
        private Point lastPoint;
        private Brush currentBrush = Brushes.Black;
        private double brushSize = 20;
        private bool isEraser;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handlers for Brush Color Buttons
        private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
        {
            currentBrush = Brushes.Black;
            isEraser = false;
        }

        private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
        {
            currentBrush = Brushes.White;
            isEraser = false;
        }

        private void btnEraser_Click(object sender, RoutedEventArgs e)
        {
            isEraser = true;
            currentBrush = Brushes.White;
        }

        // Event handler for Brush Size Slider
        private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            brushSize = brushSizeSlider.Value;
        }

        // Mouse Down event to start drawing
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            isDrawing = true;
            lastPoint = e.GetPosition(imgCanvas);
        }

        // Mouse Move event to draw on the canvas
        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                Point currentPoint = e.GetPosition(imgCanvas);
                DrawLine(lastPoint, currentPoint);
                lastPoint = currentPoint;
            }
        }

        // Mouse Up event to stop drawing
        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isDrawing = false;
        }

        // Draws a line between two points
        private void DrawLine(Point startPoint, Point endPoint)
        {
            if (isEraser)
            {
                Ellipse erase = new Ellipse
                {
                    Fill = Brushes.White,
                    Width = brushSize,
                    Height = brushSize
                };
                Canvas.SetLeft(erase, endPoint.X - brushSize / 2);
                Canvas.SetTop(erase, endPoint.Y - brushSize / 2);
                imgCanvas.Children.Add(erase);
            }
            else
            {
                Line line = new Line
                {
                    Stroke = currentBrush,
                    StrokeThickness = brushSize,
                    X1 = startPoint.X,
                    Y1 = startPoint.Y,
                    X2 = endPoint.X,
                    Y2 = endPoint.Y
                };
                imgCanvas.Children.Add(line);
            }
        }

        // Load Image Button Click event
        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == true)
            {
                var image = new System.Windows.Controls.Image();
                var bitmap = new System.Windows.Media.Imaging.BitmapImage(new Uri(openFileDialog.FileName));
                image.Source = bitmap;
                imgCanvas.Children.Clear();  // Clear any existing drawings
                imgCanvas.Children.Add(image);
            }
        }

        // Save Button Click event
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PNG Image|*.png";
            if (saveFileDialog.ShowDialog() == true)
            {
                var renderedBitmap = new RenderTargetBitmap((int)imgCanvas.ActualWidth, (int)imgCanvas.ActualHeight, 96, 96, PixelFormats.Pbgra32);
                renderedBitmap.Render(imgCanvas);

                var pngEncoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                pngEncoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(renderedBitmap));
                using (var stream = saveFileDialog.OpenFile())
                {
                    pngEncoder.Save(stream);
                }
            }
        }
    }
}