﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DrawOnImage
{
    //public partial class UserControl1 : UserControl
    //{
    //    private WriteableBitmap writeableBitmap;
    //    private int width = 1000;
    //    private int height = 1000;
    //    private bool isDrawing = false;
    //    private bool isErasing = false;
    //    private Point previousPoint;
    //    private int brushSize = 5;

    //    public UserControl1()
    //    {
    //        InitializeComponent();

    //        // Initialize WriteableBitmap and canvas
    //        writeableBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
    //        ImageBrush brush = new ImageBrush(writeableBitmap);
    //        Canvas.Background = brush;

    //        // Set the Canvas size to match the WriteableBitmap size
    //        Canvas.Width = width;
    //        Canvas.Height = height;

    //        // Add mouse event for drawing or erasing
    //        Canvas.MouseMove += Canvas_MouseMove;
    //        Canvas.MouseDown += Canvas_MouseDown;
    //        Canvas.MouseUp += Canvas_MouseUp;
    //    }
    //    // Mouse down event to start drawing or erasing
    //    private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
    //    {
    //        if (isErasing)
    //        {
    //            ErasePixel((int)e.GetPosition(Canvas).X, (int)e.GetPosition(Canvas).Y);
    //        }
    //        else
    //        {

    //            previousPoint = e.GetPosition(Canvas);
    //        }
    //    }

    //    // Mouse move event for drawing or erasing
    //    private void Canvas_MouseMove(object sender, MouseEventArgs e)
    //    {
    //        if (isDrawing)
    //        {
    //            var currentPoint = e.GetPosition(Canvas);
    //            DrawLineOnBitmap(previousPoint, currentPoint);
    //            previousPoint = currentPoint;
    //        }
    //        else if (isErasing)
    //        {
    //            // Erase when mouse is moved and in erase mode
    //            ErasePixel((int)e.GetPosition(Canvas).X, (int)e.GetPosition(Canvas).Y);
    //        }
    //    }

    //    // Mouse up event to stop drawing
    //    private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
    //    {
    //        isDrawing = false;
    //    }

    //    // Toggle Erase Mode (Erase button click event)
    //    private void EraseButton_Click(object sender, RoutedEventArgs e)
    //    {
    //        isErasing = !isErasing;
    //        if (isErasing)
    //        {
    //            EraseButton.Content = "Draw"; // Change button text to 'Draw' when in erase mode
    //        }
    //        else
    //        {
    //            EraseButton.Content = "Erase"; // Change button text to 'Erase' when not in erase mode
    //        }
    //    }

    //    // Clear the canvas (Clear button click event)
    //    private void ClearButton_Click(object sender, RoutedEventArgs e)
    //    {
    //        ClearCanvas();
    //    }

    //    // Method to draw a line on the WriteableBitmap
    //    private void DrawLineOnBitmap(Point start, Point end)
    //    {
    //        int x1 = (int)start.X;
    //        int y1 = (int)start.Y;
    //        int x2 = (int)end.X;
    //        int y2 = (int)end.Y;

    //        // Simple line drawing algorithm (Bresenham's Line Algorithm)
    //        int dx = Math.Abs(x2 - x1);
    //        int dy = Math.Abs(y2 - y1);
    //        int sx = (x1 < x2) ? 1 : -1;
    //        int sy = (y1 < y2) ? 1 : -1;
    //        int err = dx - dy;

    //        while (true)
    //        {
    //            // Draw a thicker line by drawing surrounding pixels
    //            for (int i = -brushSize / 2; i <= brushSize / 2; i++)
    //            {
    //                for (int j = -brushSize / 2; j <= brushSize / 2; j++)
    //                {
    //                    int dxAdjusted = x1 + i;
    //                    int dyAdjusted = y1 + j;

    //                    // Only draw if within bounds
    //                    if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
    //                        dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
    //                    {
    //                        SetPixel(dxAdjusted, dyAdjusted, Colors.Black);
    //                    }
    //                }
    //            }

    //            if (x1 == x2 && y1 == y2) break;
    //            int e2 = err * 2;
    //            if (e2 > -dy)
    //            {
    //                err -= dy;
    //                x1 += sx;
    //            }
    //            if (e2 < dx)
    //            {
    //                err += dx;
    //                y1 += sy;
    //            }
    //        }
    //    }

    //    // Set a pixel to a specific color
    //    private void SetPixel(int x, int y, Color color)
    //    {
    //        if (x < 0 || x >= writeableBitmap.PixelWidth || y < 0 || y >= writeableBitmap.PixelHeight)
    //            return;

    //        int stride = writeableBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
    //        int index = (y * stride) + (x * 4);

    //        byte[] pixels = new byte[4];
    //        pixels[0] = color.B;
    //        pixels[1] = color.G;
    //        pixels[2] = color.R;
    //        pixels[3] = color.A;

    //        writeableBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
    //    }

    //    private void ErasePixel(int x, int y)
    //    {
    //        // Erase multiple pixels around the cursor based on brush size
    //        for (int i = -brushSize / 2; i <= brushSize / 2; i++)
    //        {
    //            for (int j = -brushSize / 2; j <= brushSize / 2; j++)
    //            {
    //                int dxAdjusted = x + i;
    //                int dyAdjusted = y + j;

    //                // Only erase if within bounds
    //                if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
    //                    dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
    //                {
    //                    SetPixel(dxAdjusted, dyAdjusted, Colors.Transparent); // Set to transparent to "erase"
    //                }
    //            }
    //        }
    //    }

    //    // Clear the entire canvas
    //    public void ClearCanvas()
    //    {
    //        byte[] emptyPixels = new byte[width * height * 4];
    //        writeableBitmap.WritePixels(new Int32Rect(0, 0, width, height), emptyPixels, width * 4, 0);
    //    }

    //    private void BrushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    //    {
    //        brushSize = (int)e.NewValue;
    //    }
    //}

    public partial class UserControl1 : UserControl
    {
        private WriteableBitmap writeableBitmap;
        private int width = 1000;
        private int height = 1000;
        private bool isDrawing = true;
        private bool isErasing = false;
        private bool isClicked = false;
        private Point previousPoint;
        private int brushSize = 5;

        public UserControl1()
        {
            InitializeComponent();

            // Initialize WriteableBitmap and canvas
            writeableBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            ImageBrush brush = new ImageBrush(writeableBitmap);
            Canvas.Background = brush;

            // Set the Canvas size to match the WriteableBitmap size
            Canvas.Width = width;
            Canvas.Height = height;

            // Add mouse event for drawing or erasing
            Canvas.MouseMove += Canvas_MouseMove;
            Canvas.MouseDown += Canvas_MouseDown;
            Canvas.MouseUp += Canvas_MouseUp;
        }
        // Mouse down event to start drawing or erasing
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (isErasing)
            {
                isClicked = true;
                ErasePixel((int)e.GetPosition(Canvas).X, (int)e.GetPosition(Canvas).Y);
            }
            else if(isDrawing)
            {
                isClicked = true;
                previousPoint = e.GetPosition(Canvas);
            }
        }

        // Mouse move event for drawing or erasing
        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing && isClicked)
            {
                var currentPoint = e.GetPosition(Canvas);
                DrawLineOnBitmap(previousPoint, currentPoint);
                previousPoint = currentPoint;
            }
            else if (isErasing && isClicked)
            {
                // Erase when mouse is moved and in erase mode
                ErasePixel((int)e.GetPosition(Canvas).X, (int)e.GetPosition(Canvas).Y);
            }
        }

        // Mouse up event to stop drawing
        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isClicked = false;
        }

        // Toggle Erase Mode (Erase button click event)
        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            if (isErasing)
            {
                isErasing = false;
                isDrawing = true;
                EraseButton.Content = "Erase"; // Change button text to 'Erase' when in erase mode
            }
            else if(isDrawing)
            {
                isErasing = true;
                isDrawing = false;
                EraseButton.Content = "Draw"; // Change button text to 'Draw' when not in erase mode
            }
        }

        // Clear the canvas (Clear button click event)
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            ClearCanvas();
        }

        // Method to draw a line on the WriteableBitmap
        private void DrawLineOnBitmap(Point start, Point end)
        {
            int x1 = (int)start.X;
            int y1 = (int)start.Y;
            int x2 = (int)end.X;
            int y2 = (int)end.Y;

            // Simple line drawing algorithm (Bresenham's Line Algorithm)
            int dx = Math.Abs(x2 - x1);
            int dy = Math.Abs(y2 - y1);
            int sx = (x1 < x2) ? 1 : -1;
            int sy = (y1 < y2) ? 1 : -1;
            int err = dx - dy;

            while (true)
            {
                // Draw a thicker line by drawing surrounding pixels
                for (int i = -brushSize / 2; i <= brushSize / 2; i++)
                {
                    for (int j = -brushSize / 2; j <= brushSize / 2; j++)
                    {
                        int dxAdjusted = x1 + i;
                        int dyAdjusted = y1 + j;

                        // Only draw if within bounds
                        if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
                            dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
                        {
                            SetPixel(dxAdjusted, dyAdjusted, Colors.Black);
                        }
                    }
                }

                if (x1 == x2 && y1 == y2) break;
                int e2 = err * 2;
                if (e2 > -dy)
                {
                    err -= dy;
                    x1 += sx;
                }
                if (e2 < dx)
                {
                    err += dx;
                    y1 += sy;
                }
            }
        }

        // Set a pixel to a specific color
        private void SetPixel(int x, int y, Color color)
        {
            if (x < 0 || x >= writeableBitmap.PixelWidth || y < 0 || y >= writeableBitmap.PixelHeight)
                return;

            int stride = writeableBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
            int index = (y * stride) + (x * 4);

            byte[] pixels = new byte[4];
            pixels[0] = color.B;
            pixels[1] = color.G;
            pixels[2] = color.R;
            pixels[3] = color.A;

            writeableBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
        }

        private void ErasePixel(int x, int y)
        {
            // Erase multiple pixels around the cursor based on brush size
            for (int i = -brushSize / 2; i <= brushSize / 2; i++)
            {
                for (int j = -brushSize / 2; j <= brushSize / 2; j++)
                {
                    int dxAdjusted = x + i;
                    int dyAdjusted = y + j;

                    // Only erase if within bounds
                    if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
                        dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
                    {
                        SetPixel(dxAdjusted, dyAdjusted, Colors.Transparent); // Set to transparent to "erase"
                    }
                }
            }
        }

        // Clear the entire canvas
        public void ClearCanvas()
        {
            byte[] emptyPixels = new byte[width * height * 4];
            writeableBitmap.WritePixels(new Int32Rect(0, 0, width, height), emptyPixels, width * 4, 0);
        }

        private void BrushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            brushSize = (int)e.NewValue;
        }
    }
}