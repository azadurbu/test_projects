﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RectangleMove
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isDragging = false;
        private Point clickPosition;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Rectangle_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                isDragging = true;
                clickPosition = e.GetPosition(myCanvas);
                myRectangle.CaptureMouse();
            }
        }

        private void Rectangle_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point currentPosition = e.GetPosition(myCanvas);
                double offsetX = currentPosition.X - clickPosition.X;
                double offsetY = currentPosition.Y - clickPosition.Y;

                double newLeft = Canvas.GetLeft(myRectangle) + offsetX;
                double newTop = Canvas.GetTop(myRectangle) + offsetY;

                Canvas.SetLeft(myRectangle, newLeft);
                Canvas.SetTop(myRectangle, newTop);

                clickPosition = currentPosition; // Update the click position
            }
        }

        private void Rectangle_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;
            myRectangle.ReleaseMouseCapture();
        }
    }

}
