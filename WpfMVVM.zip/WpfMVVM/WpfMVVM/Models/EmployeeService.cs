﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfMVVM.Models
{
    public class EmployeeService
    {
        private static List<Employee> ObjEmployeesList;

        public EmployeeService()
        {
            ObjEmployeesList = new List<Employee>()
            {
                new Employee{ ID=101, Name="AD", Age= 40, Img = "001.png" }
            };
        }

        public List<Employee> GetAllEmployees()
        {
            return ObjEmployeesList;
        }

        public bool Add(Employee objNewEmp)
        {
            if(objNewEmp.ID != 0 && objNewEmp.Age != 0 && !string.IsNullOrEmpty(objNewEmp.Name))
            {
                ObjEmployeesList.Add(objNewEmp);
            }
            
            return true;
        }

        public Employee Search(int id)
        {
            return ObjEmployeesList.FirstOrDefault(e=>e.ID == id);
        }

        public bool Update(Employee ObjEmployeesToUpdate)
        {
            bool IsUpdated = false;

            //for (int i = 0; i < ObjEmployeesList.Count; i++)
            //{
            //    if(ObjEmployeesList[i].ID == ObjEmployeesToUpdate.ID)
            //    {
            //        ObjEmployeesList[i].Name = ObjEmployeesToUpdate.Name;
            //        ObjEmployeesList[i].Age = ObjEmployeesToUpdate.Age;
            //        IsUpdated = true;
            //        break;
            //    }
            //}

            Employee emp = ObjEmployeesList.FirstOrDefault(e => e.ID == ObjEmployeesToUpdate.ID);

            if(emp != null)
            {
                emp.Name = ObjEmployeesToUpdate.Name;
                emp.Age = ObjEmployeesToUpdate.Age;
                IsUpdated = true;
            }
            return IsUpdated;
        }

        public bool Delete(int iD)
        {
            bool IsDeleted = false;
            Employee emp = ObjEmployeesList.FirstOrDefault(e => e.ID == iD);
            if (emp != null)
            {
                ObjEmployeesList.Remove(emp);
                IsDeleted = true;
            }
            return IsDeleted;
        }

    }
}
