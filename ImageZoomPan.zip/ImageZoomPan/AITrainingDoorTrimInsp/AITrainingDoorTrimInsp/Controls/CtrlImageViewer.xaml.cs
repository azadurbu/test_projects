﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AITrainingDoorTrimInsp.Controls
{
    /// <summary>
    /// Interaction logic for CtrlImageViewer.xaml
    /// </summary>
    public partial class CtrlImageViewer : UserControl
    {
        private Canvas canvas = null;
        private double ScreenRatio = .2;
        private System.Windows.Point startPoint;
        private System.Windows.Point origin;
        public CtrlImageViewer()
        {
            InitializeComponent();
            string imgPath = @"\Images\result.jpg";

            img.Source = new BitmapImage(new Uri(imgPath, UriKind.Relative));

            canvas = zbImgCanvas;
            //canvas zoom pan action set
            canvas.MouseWheel += ZoomPan_MouseWheel;
            canvas.MouseLeftButtonDown += ZoomPan_MouseLeftButtonDown;
            canvas.MouseLeftButtonUp += ZoomPan_MouseLeftButtonUp;
            canvas.MouseMove += ZoomPan_MouseMove;
            canvas.PreviewMouseRightButtonDown += ZoomPan_PreviewMouseRightButtonDown;
            canvas.Loaded += ZoomPan_Loaded;

            // resize and center the image at the beginning
            if (canvas is FrameworkElement fe) fe.Loaded += (s, e) => zoomBorder.ImageLoad(canvas);
        }

        #region canvas zoom pan events
        private void ZoomPan_Loaded(object sender, RoutedEventArgs e)
        {
            zoomBorder.ZoomOutViewCentered();
        }

        private void ZoomPan_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            zoomBorder.Reset();
        }

        private void ZoomPan_MouseMove(object sender, MouseEventArgs e)
        {
            if (canvas != null)
            {
                Canvas childCanvas = (Canvas)canvas;
                if (canvas.IsMouseCaptured)
                {
                    var tt = zoomBorder.GetTranslateTransform(canvas);
                    System.Windows.Vector v = startPoint - e.GetPosition(this);
                    tt.X = origin.X - v.X;
                    tt.Y = origin.Y - v.Y;
                    zoomBorder.ConstrainTranslationToBounds();
                }
            }
        }

        private void ZoomPan_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (canvas != null)
            {
                canvas.ReleaseMouseCapture();
                zoomBorder.Cursor = Cursors.Arrow;
            }
        }

        private void ZoomPan_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (canvas != null)
            {
                var tt = zoomBorder.GetTranslateTransform(canvas);
                startPoint = e.GetPosition(this);
                origin = new System.Windows.Point(tt.X, tt.Y);
                this.Cursor = Cursors.Hand;
                canvas.CaptureMouse();
            }
        }

        private void ZoomPan_MouseWheel(object sender, MouseWheelEventArgs e)
        {

            if (canvas != null)
            {
                var st = zoomBorder.GetScaleTransform(canvas);
                var tt = zoomBorder.GetTranslateTransform(canvas);

                double zoom = e.Delta > 0 ? ScreenRatio : -ScreenRatio;
                if (!(e.Delta > 0) && (st.ScaleX <= ScreenRatio + .1 || st.ScaleY <= ScreenRatio + .1))
                {
                    zoomBorder.Reset();
                    return;
                }

                System.Windows.Point relative = e.GetPosition(canvas);

                double absoluteX = relative.X * st.ScaleX + tt.X;
                double absoluteY = relative.Y * st.ScaleY + tt.Y;

                st.ScaleX += zoom;
                st.ScaleY += zoom;

                tt.X = absoluteX - relative.X * st.ScaleX;
                tt.Y = absoluteY - relative.Y * st.ScaleY;
            }
        }
        #endregion
    }
}
