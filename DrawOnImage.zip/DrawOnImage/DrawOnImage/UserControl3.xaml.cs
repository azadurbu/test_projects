﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DrawOnImage
{
    public partial class UserControl3 : UserControl
    {
        private WriteableBitmap writeableBitmap;
        private int width = 1000;
        private int height = 1000;
        private bool isDrawing = true;
        private bool isErasing = false;
        private bool isClicked = false;
        private bool isCircle = false;
        private Point previousPoint;
        private int brushSize = 5;
        private Stack<WriteableBitmap> undoStack = new Stack<WriteableBitmap>(); // Undo stack
        private Color brushColor = Colors.Black;

        public UserControl3()
        {
            InitializeComponent();
            // Initialize WriteableBitmap and canvas
            writeableBitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            ImageBrush brush = new ImageBrush(writeableBitmap);
            canvas.Background = brush;

            // Set the Canvas size to match the WriteableBitmap size
            canvas.Width = width;
            canvas.Height = height;
            canvasImage.Width = width;
            canvasImage.Height = height;

            // Add mouse event for drawing or erasing
            canvas.MouseMove += Canvas_MouseMove;
            canvas.MouseDown += Canvas_MouseDown;
            canvas.MouseUp += Canvas_MouseUp;
        }


        #region canvas actiuon
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var startPoint = e.GetPosition(canvas);
            // Map the canvas coordinates to the WriteableBitmap coordinates
            double scaleX = writeableBitmap.PixelWidth / canvas.ActualWidth;
            double scaleY = writeableBitmap.PixelHeight / canvas.ActualHeight;

            int bitmapX = (int)(startPoint.X * scaleX);
            int bitmapY = (int)(startPoint.Y * scaleY);

            if (isErasing)
            {
                isClicked = true;
                ErasePixel(bitmapX, bitmapY);
                SaveUndoState();
            }
            else if (isDrawing)
            {
                isClicked = true;
                previousPoint = new Point(bitmapX, bitmapY);
                DrawLineOnBitmap(previousPoint, new Point(bitmapX, bitmapY));
                SaveUndoState();
            }
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            var startPoint = e.GetPosition(canvas);
            double scaleX = writeableBitmap.PixelWidth / canvas.ActualWidth;
            double scaleY = writeableBitmap.PixelHeight / canvas.ActualHeight;

            int bitmapX = (int)(startPoint.X * scaleX);
            int bitmapY = (int)(startPoint.Y * scaleY);

            if (isDrawing && isClicked)
            {
                DrawLineOnBitmap(previousPoint, new Point(bitmapX, bitmapY));
                previousPoint = new Point(bitmapX, bitmapY);
            }
            else if (isErasing && isClicked)
            {
                ErasePixel(bitmapX, bitmapY);
            }
        }

        // Mouse up event to stop drawing
        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isClicked = false;
        }
        #endregion


        #region form button action
        // Load Image Button Click
        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg;*.bmp;*.gif)|*.png;*.jpg;*.jpeg;*.bmp;*.gif";

            if (openFileDialog.ShowDialog() == true)
            {
                var image = new System.Windows.Controls.Image();
                var bitmap = new System.Windows.Media.Imaging.BitmapImage(new Uri(openFileDialog.FileName));
                image.Source = bitmap;
                canvasImage.Children.Clear();
                canvasImage.Children.Add(image);
                canvasImage.Width = bitmap.PixelWidth;
                canvasImage.Height = bitmap.PixelHeight;
                canvas.Height = bitmap.PixelHeight;
                canvas.Width = bitmap.PixelWidth;

                Window parentWindow = Window.GetWindow(this);
                parentWindow.Width = bitmap.PixelWidth + 35;
                parentWindow.Height = bitmap.PixelHeight;
            }
        }
        
        // Save Button Click
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Canvas canvas1 = canvasImage;
            Canvas canvas2 = canvas;

            RenderTargetBitmap renderBitmap1 = new RenderTargetBitmap((int)canvas1.ActualWidth,
                (int)canvas1.ActualHeight, 96d, 96d, PixelFormats.Pbgra32);
            canvas1.Measure(new Size((int)canvas1.ActualWidth, (int)canvas1.ActualHeight));
            canvas1.Arrange(new Rect(new Size((int)canvas1.ActualWidth, (int)canvas1.ActualHeight)));
            renderBitmap1.Render(canvas1);

            RenderTargetBitmap renderBitmap2 = new RenderTargetBitmap((int)canvas2.ActualWidth,
                (int)canvas2.ActualHeight, 96d, 96d, PixelFormats.Pbgra32);
            canvas2.Measure(new Size((int)canvas2.ActualWidth, (int)canvas2.ActualHeight));
            canvas2.Arrange(new Rect(new Size((int)canvas2.ActualWidth, (int)canvas2.ActualHeight)));
            renderBitmap2.Render(canvas2);

            var dg = new DrawingGroup();

            var id1 = new ImageDrawing(renderBitmap1, new Rect(0, 0, renderBitmap1.Width, renderBitmap1.Height));
            var id2 = new ImageDrawing(renderBitmap2, new Rect(0, 0, renderBitmap2.Width, renderBitmap2.Height));

            dg.Children.Add(id1);
            dg.Children.Add(id2);

            RenderTargetBitmap combinedImg = new RenderTargetBitmap((int)Math.Max(renderBitmap1.Width, renderBitmap2.Width),
                (int)Math.Max(renderBitmap1.Height, renderBitmap2.Height), 96, 96, PixelFormats.Pbgra32);


            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                dc.DrawDrawing(dg);
            }
            combinedImg.Render(dv);

            SaveImage(combinedImg);
        }

        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {
            if (undoStack.Count > 0)
            {
                writeableBitmap = undoStack.Pop();
                canvas.Background = new ImageBrush(writeableBitmap);
            }
        }

        // Toggle Erase Mode (Erase button click event)
        private void EraseButton_Click(object sender, RoutedEventArgs e)
        {
            if (isErasing)
            {
                isErasing = false;
                isDrawing = true;
                EraseButton.Content = "Erase";
            }
            else if (isDrawing)
            {
                isErasing = true;
                isDrawing = false;
                EraseButton.Content = "Draw";
                brushColor = Colors.Transparent;
            }
        }
        
        // Toggle Circle Mode (Circle button click event)
        private void CircleButton_Click(object sender, RoutedEventArgs e)
        {
            if(isCircle)
            {
                isCircle = false;
                CircleButton.Content = "Circle";
            }
            else
            {
                isCircle = true;
                CircleButton.Content = "Rectangle";
            }
        }

        private void btnBlackBrush_Click(object sender, RoutedEventArgs e)
        {
            brushColor = Colors.Black;
            isDrawing = true;
            isErasing = false;
            EraseButton.Content = "Erase";
        }

        private void btnWhiteBrush_Click(object sender, RoutedEventArgs e)
        {
            brushColor = Colors.White;
            isDrawing = true;
            isErasing = false;
            EraseButton.Content = "Erase";
        }

        private void brushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            brushSize = (int)e.NewValue;
        }
        #endregion
        

        #region helper functions
        // Save the current canvas state to the undo stack
        private void SaveUndoState()
        {
            var copyBitmap = new WriteableBitmap(writeableBitmap);
            undoStack.Push(copyBitmap);
        }

        private void SaveImage(RenderTargetBitmap renderTargetBitmap)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JPEG Image(*.jpg)|*.jpg|BMP Image (*.bmp*)|*.bmp|PNG Image(*.png)|*.png|GIF Image(*.gif)|*.gif";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                BitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));

                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    encoder.Save(fs);
                }
            }
        }
        
        private void DrawLineOnBitmap(Point start, Point end)
        {
            int x1 = (int)start.X;
            int y1 = (int)start.Y;
            int x2 = (int)end.X;
            int y2 = (int)end.Y;

            int dx = Math.Abs(x2 - x1);
            int dy = Math.Abs(y2 - y1);
            int sx = (x1 < x2) ? 1 : -1;
            int sy = (y1 < y2) ? 1 : -1;
            int err = dx - dy;

            while (true)
            {
                if (isCircle)
                    DrawCircle(x1, y1);
                else
                    DrawRectangle(x1, y1);

                if (x1 == x2 && y1 == y2) break;
                int e2 = err * 2;
                if (e2 > -dy)
                {
                    err -= dy;
                    x1 += sx;
                }
                if (e2 < dx)
                {
                    err += dx;
                    y1 += sy;
                }
            }
        }

        private void ErasePixel(int x, int y)
        {
            if (isCircle)
                DrawCircle(x, y);
            else
                DrawRectangle(x, y);
        }
                
        private void DrawRectangle(int x1, int y1)
        {
            for (int i = -brushSize; i <= brushSize; i++)
            {
                for (int j = -brushSize; j <= brushSize; j++)
                {
                    int dxAdjusted = x1 + i;
                    int dyAdjusted = y1 + j;

                    if (dxAdjusted >= 0 && dxAdjusted < writeableBitmap.PixelWidth &&
                        dyAdjusted >= 0 && dyAdjusted < writeableBitmap.PixelHeight)
                    {
                        SetPixel(dxAdjusted, dyAdjusted, brushColor);
                    }
                }
            }
        }

        private void DrawCircle(int centerX, int centerY)
        {
            int radius = brushSize;
            for (int dx = -radius; dx <= radius; dx++)
            {
                for (int dy = -radius; dy <= radius; dy++)
                {
                    if (dx * dx + dy * dy <= radius * radius)
                    {
                        int x = centerX + dx;
                        int y = centerY + dy;

                        if (x >= 0 && x < writeableBitmap.PixelWidth && y >= 0 && y < writeableBitmap.PixelHeight)
                        {
                            SetPixel(x, y, brushColor);
                        }
                    }
                }
            }
        }

        private void SetPixel(int x, int y, Color color)
        {
            if (x < 0 || x >= writeableBitmap.PixelWidth || y < 0 || y >= writeableBitmap.PixelHeight)
                return;

            int stride = writeableBitmap.PixelWidth * 4; // 4 bytes per pixel (BGRA)
            int index = (y * stride) + (x * 4);

            byte[] pixels = new byte[4];
            pixels[0] = color.B;
            pixels[1] = color.G;
            pixels[2] = color.R;
            pixels[3] = color.A;

            writeableBitmap.WritePixels(new Int32Rect(x, y, 1, 1), pixels, stride, 0);
        }
        #endregion
    }
}
